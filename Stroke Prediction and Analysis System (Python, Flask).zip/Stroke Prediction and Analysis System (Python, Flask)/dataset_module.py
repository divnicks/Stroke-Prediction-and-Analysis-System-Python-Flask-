def load_dataset(file_path):
    dataset = {}

    with open(file_path, 'r', encoding='utf-8') as file:
        # Read the header row
        headers = file.readline().strip().split(',')
        
        # Read the rest of the file line by line
        for index, line in enumerate(file):
            values = line.strip().split(',')
            
            # Create a dictionary for each record
            record = {headers[i]: values[i] for i in range(len(headers))}
            
            # Store the record in dataset using an index as the key
            dataset[index] = record
    
    return dataset
