from flask import Flask, render_template, request, redirect, url_for, flash
import dataset_module
import query_module
import os

app = Flask(__name__)
app.secret_key = "your_secret_key"

DATASET = None

print("Current working directory:", os.getcwd())

@app.route('/', methods=['GET', 'POST'])
def index():
    global DATASET
    if request.method == 'POST':
        file_path = request.form.get("file_path", "data.csv").strip()
        if not file_path:
            file_path = "data.csv"
        try:
            DATASET = dataset_module.load_dataset(file_path)
            flash(f"Dataset loaded successfully with {len(DATASET)} records.", "success")
            return redirect(url_for('menu'))
        except Exception as e:
            flash(f"Error loading dataset: {str(e)}", "danger")
            return redirect(url_for('index'))
    return render_template('index.html')

@app.route('/menu')
def menu():
    if DATASET is None:
        flash("Please load the dataset first.", "warning")
        return redirect(url_for('index'))
   
    query_options = [
        {"name": "Stroke Smokers with Hypertension", "endpoint": "stroke_smokers_hypertension"},
        {"name": "Stroke Heart Disease with Glucose", "endpoint": "stroke_heart_disease_glucose"},
        {"name": "Hypertension Stroke by Gender", "endpoint": "hypertension_stroke_by_gender"},
        {"name": "Smoking Stroke Analysis", "endpoint": "smoking_stroke_analysis"},
        {"name": "Stroke Residence Analysis", "endpoint": "stroke_residence_analysis"},
        {"name": "Dietary Habits (Stroke vs Non-Stroke)", "endpoint": "dietary_habits_stroke"},
        {"name": "Hypertension Stroke Records", "endpoint": "hypertension_stroke_records"},
        {"name": "Hypertension Stroke Status", "endpoint": "hypertension_stroke_status"},
        {"name": "Stroke Heart Disease Retrieve", "endpoint": "stroke_heart_disease_retrieve"},
        {"name": "Descriptive Feature Analysis", "endpoint": "descriptive_feature_analysis"},
        {"name": "Average Sleep Hours by Stroke", "endpoint": "average_sleep_hours_by_stroke"}
    ]
    return render_template('menu.html', query_options=query_options)

@app.route('/query/<query_type>', methods=['GET', 'POST'])
def query(query_type):
    global DATASET
    result = None
    error = None
    output_file = f"{query_type}.csv"

    if DATASET is None:
        flash("Dataset not loaded. Please load the dataset first.", "warning")
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        try:
            result = getattr(query_module, query_type)(DATASET, output_file)
        except AttributeError:
            error = "Invalid query type selected."
        except Exception as e:
            error = f"An error occurred: {str(e)}"
    
    return render_template('query.html', query_type=query_type, result=result, error=error, output_file=output_file)

@app.route('/explore/<query_type>', methods=['GET', 'POST'])
def explore(query_type):
    output_file = f"{query_type}.csv"
    available_features = []

    # Read available features from the output file
    try:
        with open(output_file, "r", encoding="utf-8") as file:
            available_features = file.readline().strip().split(",")  # Read column names
    except FileNotFoundError:
        flash("No query results available to explore. Run a query first.", "danger")
        return redirect(url_for('menu'))

    selected_features = []
    results = []

    if request.method == 'POST':
        selected_features = request.form.getlist('features')
        if selected_features:
            results = query_module.explore_results(output_file, selected_features)
        else:
            flash("Please select at least one feature to explore.", "warning")

    return render_template('explore.html', query_type=query_type, features=available_features, selected_features=selected_features, results=results)

if __name__ == '__main__':
    app.run(debug=True)
