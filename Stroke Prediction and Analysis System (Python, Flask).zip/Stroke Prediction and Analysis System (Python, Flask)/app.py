from flask import Flask, render_template, request, redirect, url_for, flash, session
import Extra
import dataset_module
import query_module



app = Flask(__name__)
app.secret_key = "your_secret_key"
app.config['SESSION_TYPE'] = 'filesystem'

DATASET = None

@app.route('/', methods=['GET', 'POST'])
def index():
    global DATASET
    if request.method == 'POST':
        file_path = request.form.get("file_path", "data.csv").strip()
        if not file_path:
            file_path = "data.csv"
        try:
            DATASET = dataset_module.load_dataset(file_path)
            flash(f"Dataset loaded successfully with {len(DATASET)} records.", "success")
            return redirect(url_for('menu'))
        except Exception as e:
            flash(f"Error loading dataset: {str(e)}", "danger")
            return redirect(url_for('index'))
    return render_template('index.html')


@app.route('/menu')
def menu():
    if DATASET is None:
        flash("Please load the dataset first.", "warning")
        return redirect(url_for('index'))

    query_options = [
        {"name": "🔍 Explore Dataset", "endpoint": "explore_dataset"},
        {"name": "Compute the average age, modal age, median age of those who smoked and had hypertensions that resulted in stroke", "endpoint": "stroke_smokers_hypertension"},
        {"name": "Compute the average age, modal age, median age, and average glucose level of those who had heart disease that resulted in stroke", "endpoint": "stroke_heart_disease_glucose"},
        {"name": "Compute the average age, modal age, median age of patients based on genders of those whose hypertensions resulted in stroke and of those whose hypertensions did not result in stroke", "endpoint": "hypertension_stroke_by_gender"},
        {"name": "Compute the average age, modal age, median age of those whose smoking habits result in stroke and for those whose smoking habit did not result in stroke", "endpoint": "smoking_stroke_analysis"},
        {"name": "Compute the average age, modal age, median age of those who lived in urban areas and for those in rural areas that had stroke", "endpoint": "stroke_residence_analysis"},
        {"name": "Retrieves the dietary habit(s) of those who had stroke and those who did not have stroke", "endpoint": "dietary_habits_stroke"},
        {"name": "Returns anyone whose hypertension resulted in stroke.", "endpoint": "hypertension_stroke_records"},
        {"name": "Retrieve those who hypertension did not result in stroke and those whose hypertension resulted in stroke", "endpoint": "hypertension_stroke_status"},
        {"name": "Returns everyone with heart disease that has stroke", "endpoint": "stroke_heart_disease_retrieve"},
        {"name": "Descriptive Feature Analysis", "endpoint": "descriptive_feature_analysis"},
        {"name": "Retrieve the average sleep hours of those who had stroke and those who did not have stroke", "endpoint": "average_sleep_hours_by_stroke"}
    ]
    return render_template('menu.html', query_options=query_options)


@app.route('/query/<query_type>', methods=['GET', 'POST'])
def query(query_type):
    global DATASET
    result = None
    error = None
    output_file = f"{query_type}.csv"

    if DATASET is None:
        flash("Dataset not loaded. Please load the dataset first.", "warning")
        return redirect(url_for('index'))

    try:
        query_functions = {
            "stroke_smokers_hypertension": query_module.stroke_smokers_hypertension,
            "stroke_heart_disease_glucose": query_module.stroke_heart_disease_glucose,
            "hypertension_stroke_by_gender": query_module.hypertension_stroke_by_gender,
            "smoking_stroke_analysis": query_module.smoking_stroke_analysis,
            "stroke_residence_analysis": query_module.stroke_residence_analysis,
            "dietary_habits_stroke": query_module.dietary_habits_stroke,
            "hypertension_stroke_records": query_module.hypertension_stroke_records,
            "hypertension_stroke_status": query_module.hypertension_stroke_status,
            "stroke_heart_disease_retrieve": query_module.stroke_heart_disease_retrieve,
            "average_sleep_hours_by_stroke": query_module.average_sleep_hours_by_stroke
        }

        if request.method == 'POST':
            if query_type in query_functions:
                result = query_functions[query_type](DATASET, output_file)
            elif query_type == "descriptive_feature_analysis":
                feature = request.form.get('feature', '').strip()
                if not feature:
                    error = "Please enter a valid feature name."
                else:
                    result = query_module.descriptive_feature_analysis(DATASET, feature, output_file)
            else:
                error = "Invalid query type selected."
    except Exception as e:
        error = f"An error occurred: {str(e)}"

    return render_template('query.html', query_type=query_type, result=result, error=error, output_file=output_file)


@app.route('/explore_dataset', methods=['GET', 'POST'])
def explore_dataset():
    global DATASET
    if DATASET is None:
        flash("Please load the dataset first.", "warning")
        return redirect(url_for('index'))

    column_headers = list(DATASET[next(iter(DATASET))].keys()) if DATASET else []
    all_results = list(DATASET.values())
    filtered_results = all_results
    error = None

    numeric_ranges = {
        "ID": {"min": "", "max": ""}
    }
    binary_filters = {}
    filtered_unique_values = {}

    # Identify binary features for filtering
    for col in column_headers:
        unique_vals = {r[col] for r in all_results}
        if unique_vals == {"0", "1"}:
            filtered_unique_values[col] = sorted(unique_vals)

    if request.method == 'POST':
        try:
            # Handle numeric range filtering
            min_id = request.form.get("min_id")
            max_id = request.form.get("max_id")
            if min_id and max_id:
                min_val = int(min_id)
                max_val = int(max_id)
                filtered_results = [r for r in filtered_results if min_val <= int(r["ID"]) <= max_val]
                numeric_ranges["ID"]["min"] = min_id
                numeric_ranges["ID"]["max"] = max_id
        except ValueError:
            error = "Invalid ID range."

        # Handle binary checkbox filters
        for key in filtered_unique_values.keys():
            selected_values = request.form.getlist(f"binary_{key}")
            binary_filters[key] = selected_values
            if selected_values:
                filtered_results = [r for r in filtered_results if r[key] in selected_values]

    return render_template(
        'explore_dataset.html',
        column_headers=column_headers,
        filtered_results=filtered_results,
        numeric_ranges=numeric_ranges,
        binary_filters=binary_filters,
        filtered_unique_values=filtered_unique_values,
        error=error
    )




@app.route('/explore/<query_type>', methods=['GET', 'POST'])
def explore(query_type):
    error = None
    is_nested_result = False  # <== Flag to handle special display
    nested_data = {}

    if query_type == "explore_dataset":
        results = list(DATASET.values())
        column_headers = list(DATASET[next(iter(DATASET))].keys()) if results else []
    else:
        results, column_headers = Extra.load_query_results(f"{query_type}.csv")
        if not results:
            flash("Query results not found. Please run a query first.", "warning")
            return redirect(url_for('menu'))

    # handling for nested result - dietary_habits_stroke)
    if query_type == "dietary_habits_stroke" and isinstance(results, dict) and "Counts" in results and "Records" in results:
        is_nested_result = True
        nested_data = results  # keep original structure
        return render_template(
            "explore.html",
            query_type=query_type,
            is_nested_result=is_nested_result,
            nested_data=nested_data,
            error=error
        )

    # list of dictionaries processing
    all_column_headers = list(results[0].keys()) if results else []
    filtered_results = results
    selected_features = request.form.getlist('features') or all_column_headers

    if "ID" not in selected_features and "ID" in all_column_headers:
        selected_features.insert(0, "ID")

    filtered_unique_values = {
        col: sorted({record[col] for record in results if col in record})
        for col in all_column_headers
    }

    if request.method == 'POST':
        id_min = request.form.get("id_min")
        id_max = request.form.get("id_max")
        if id_min and id_max:
            try:
                id_min_val = int(id_min)
                id_max_val = int(id_max)
                filtered_results = [
                    r for r in filtered_results
                    if "ID" in r and id_min_val <= int(r["ID"]) <= id_max_val
                ]
            except ValueError:
                error = "Invalid ID range."

        for feature in all_column_headers:
            values = filtered_unique_values.get(feature, [])
            if values == ['0', '1'] or values == ['1', '0']:
                selected = request.form.getlist(f"{feature}_filter")
                if selected:
                    filtered_results = [
                        r for r in filtered_results
                        if r.get(feature) in selected
                    ]

    return render_template(
        "explore.html",
        query_type=query_type,
        column_headers=selected_features,
        all_column_headers=all_column_headers,
        filtered_results=filtered_results,
        filtered_unique_values=filtered_unique_values,
        is_nested_result=is_nested_result,
        nested_data=nested_data,
        error=error
    )

if __name__ == '__main__':
    app.run(debug=True)
