from dataset_module import load_dataset
import query_module

def main():
    # Load dataset 
    dataset = load_dataset('data.csv')
    print("\n Dataset 'data.csv' loaded successfully.")

    while True:
        # Menu of options
        menu = """
Please enter a number between 1 and 11 to perform a task (Press ENTER to quit):

1. Compute average, modal, and median age of smokers with hypertension that resulted in stroke.
2. Compute average, modal, median age, and average glucose level of those with heart disease that resulted in stroke.
3. Analyze average, modal, and median age by gender for hypertension cases with and without stroke.
4. Analyze average, modal, and median age for smokers with and without stroke.
5. Analyze average, modal, and median age for urban and rural residents who had stroke.
6. Retrieve dietary habits of those with and without stroke.
7. Retrieve patients whose hypertension resulted in stroke.
8. Retrieve patients whose hypertension did and did not result in stroke.
9. Retrieve patients with heart disease who had stroke.
10. Get descriptive statistics of any feature (you will be prompted to enter the feature).
11. Compute average sleep hours of those with and without stroke.

Enter your choice (1-11) or press ENTER to exit: """
        
        # Get user input
        choice = input(menu).strip()

        # Check if user wants to exit
        if choice == "":
            print("\n Exiting. Goodbye!")
            break

        # Dictionary mapping choice to function
        functions = {
            "1": query_module.stroke_smokers_hypertension,
            "2": query_module.stroke_heart_disease_glucose,
            "3": query_module.hypertension_stroke_by_gender,
            "4": query_module.smoking_stroke_analysis,
            "5": query_module.stroke_residence_analysis,
            "6": query_module.dietary_habits_stroke,
            "7": query_module.hypertension_stroke_records,
            "8": query_module.hypertension_stroke_status,
            "9": query_module.stroke_heart_disease_retrieve,
            "10": "descriptive",  # Special case to select the feature the user wants
            "11": query_module.average_sleep_hours_by_stroke
        }

        # Execute function
        if choice in functions:
            print("\n Processing, please wait...")

            if choice == "10":
                feature = input("Enter the feature you want to analyze (e.g., 'Age', 'Average Glucose Level', 'Sleep Hours'): ").strip()
                result = query_module.descriptive_feature_analysis(dataset, feature)
                print("\n Descriptive statistics computed and saved as 'descriptive_statistics.csv'")
            elif choice == "8":
                result = functions[choice](dataset)
                print("\n Results saved as 'hypertension_stroke.csv' and 'hypertension_no_stroke.csv'")
            else:
                result = functions[choice](dataset)
                print(f"\n Operation completed. File saved: '{result_file_name(choice)}'")

            # Display output 
            print("\n Here are the results:")
            if isinstance(result, dict):
                display_dict(result)
            elif isinstance(result, list):
                for item in result:
                    print(item)
            else:
                print(result)
        else:
            print("\n Invalid choice. Please enter a number between 1 and 11 or press ENTER to exit.")

# Function to return file name ofeach function
def result_file_name(choice):
    file_names = {
        "1": "stroke_smokers_hypertension.csv",
        "2": "stroke_heart_disease.csv",
        "3": "hypertension_stroke_by_gender.csv",
        "4": "smoking_stroke_analysis.csv",
        "5": "stroke_residence_analysis.csv",
        "6": "dietary_habits_stroke.csv",
        "7": "hypertension_stroke_patients.csv",
        "8": "hypertension_stroke.csv and hypertension_no_stroke.csv",
        "9": "stroke_heart_disease_retrieve.csv",
        "10": "descriptive_statistics.csv",
        "11": "average_sleep_hours_by_stroke.csv"
    }
    return file_names.get(choice, "Unknown file")

# function to print dictionary results well
def display_dict(d, indent=0):
    for key, value in d.items():
        print('  ' * indent + str(key) + ": ", end="")
        if isinstance(value, dict):
            print()
            display_dict(value, indent + 1)
        else:
            print(value)

# Run the user interface 
if __name__ == "__main__":
    main()
