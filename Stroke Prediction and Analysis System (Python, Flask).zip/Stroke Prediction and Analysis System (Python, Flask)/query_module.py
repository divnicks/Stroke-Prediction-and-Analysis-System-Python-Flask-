

def percentile(data, percent):
    if not data:
        return None
    data_sorted = sorted(data)
    k = (len(data_sorted) - 1) * (percent / 100)
    f = int(k)
    c = min(f + 1, len(data_sorted) - 1)
    if f == c:
        return data_sorted[int(k)]
    d0 = data_sorted[f] * (c - k)
    d1 = data_sorted[c] * (k - f)
    return d0 + d1


def mean(values):
    return sum(values) / len(values) if values else 0


def median(values):
    values_sorted = sorted(values)
    n = len(values_sorted)
    if n % 2 == 1:
        return values_sorted[n // 2]
    else:
        mid1, mid2 = values_sorted[n // 2 - 1], values_sorted[n // 2]
        return (mid1 + mid2) / 2


def mode(values):
    frequency = {}
    for value in values:
        frequency[value] = frequency.get(value, 0) + 1
    max_count = max(frequency.values(), default=0)
    mode_values = [key for key, count in frequency.items() if count == max_count]
    return mode_values[0] if mode_values else None


def variance(values):
    if not values or len(values) < 2:
        return 0
    avg = mean(values)
    return sum((x - avg) ** 2 for x in values) / len(values)


def standard_deviation(values):
    return variance(values) ** 0.5


def descriptive_statistics(dataset, feature, output_file):
    values = []
    for record in dataset.values():
        try:
            values.append(float(record[feature]))
        except ValueError:
            continue

    if not values:
        stats_result = "No data available"
    else:
        stats_result = {
            "Mean": mean(values),
            "Standard Deviation": standard_deviation(values),
            "Min": min(values),
            "Max": max(values),
            "25%": percentile(values, 25),
            "50%": percentile(values, 50),
            "75%": percentile(values, 75)
        }
    save_to_file(stats_result, output_file)
    return stats_result


def save_to_file(data, output_file):
    with open(output_file, "w", encoding="utf-8") as file:
        if isinstance(data, dict):
            file.write("Metric,Value\n")
            for key, value in data.items():
                file.write(f'"{key}","{value}"\n')
        elif isinstance(data, list):
            file.write("Value\n")
            for item in data:
                file.write(f'"{item}"\n')
        else:
            file.write("Value\n")
            file.write(f'"{data}"\n')


def compute_statistics(dataset, condition, output_file):
    filtered_data = [record for record in dataset.values() if condition(record)]
    if not filtered_data:
        save_to_file("No data available", output_file)
        return "No data available"

    ages = [int(record["Age"]) for record in filtered_data]
    stats_result = {
        "Average Age": mean(ages),
        "Modal Age": mode(ages),
        "Median Age": median(ages)
    }
    save_to_file(stats_result, output_file)
    return stats_result


#i.	A function for computing the average age, modal age, median age of those who smoked and had hypertensions that resulted in stroke.
def stroke_smokers_hypertension(dataset, output_file="stroke_smokers_hypertension.csv"):
    return compute_statistics(dataset, lambda r: r["Smoking Status"] != "Never" and r["Hypertension"] == "1" and r["Stroke Occurrence"] == "1", output_file)



# ii. A function for computing the average age, modal age, median age, and average glucose level of those who had heart disease that resulted in stroke.
def stroke_heart_disease_glucose(dataset, output_file="stroke_heart_disease.csv"):
    filtered_data = [record for record in dataset.values() if record["Heart Disease"] == "1" and record["Stroke Occurrence"] == "1"]
    
    if not filtered_data:
        save_to_file("No data available", output_file)
        return "No data available"

    ages = [int(record["Age"]) for record in filtered_data]
    glucose = [float(record["Average Glucose Level"]) for record in filtered_data if record["Average Glucose Level"]]

    stats_result = {
        "Average Age": mean(ages),
        "Modal Age": mode(ages),
        "Median Age": median(ages),
        "Average Glucose Level": mean(glucose) if glucose else "N/A"
    }

    save_to_file(stats_result, output_file)
    return stats_result


#iii. A function for computing the average age, modal age, median age of patients based on genders of those whose hypertensions resulted in stroke and of those whose hypertensions did not result in stroke.
def hypertension_stroke_by_gender(dataset, output_file="hypertension_stroke_by_gender.csv"):
    results = {}

    conditions = {
        "Hypertension with Stroke": lambda r: r["Hypertension"] == "1" and r["Stroke Occurrence"] == "1",
        "Hypertension without Stroke": lambda r: r["Hypertension"] == "1" and r["Stroke Occurrence"] == "0"
    }

    for condition_name, condition in conditions.items():
        gender_stats = {}
        filtered_data = [record for record in dataset.values() if condition(record)]

        if not filtered_data:
            results[condition_name] = "No data available"
            continue

        genders = set(record["Gender"] for record in filtered_data)
        for gender in genders:
            gender_data = [int(record["Age"]) for record in filtered_data if record["Gender"] == gender]

            if gender_data:
                gender_stats[gender] = {
                    "Average Age": mean(gender_data),
                    "Modal Age": mode(gender_data),
                    "Median Age": median(gender_data)
                }

        results[condition_name] = gender_stats

    save_to_file(results, output_file)
    return results



#iv.	A function for computing the average age, modal age, median age of those whose smoking habits result in stroke and for those whose smoking habit did not result in stroke
def smoking_stroke_analysis(dataset, output_file="smoking_stroke_analysis.csv"):
    results = {}

    conditions = {
        "Smokers with Stroke": lambda r: r["Smoking Status"] != "Never" and r["Stroke Occurrence"] == "1",
        "Smokers without Stroke": lambda r: r["Smoking Status"] != "Never" and r["Stroke Occurrence"] == "0"
    }

    for condition_name, condition in conditions.items():
        filtered_data = [record for record in dataset.values() if condition(record)]

        if not filtered_data:
            results[condition_name] = "No data available"
            continue

        ages = [int(record["Age"]) for record in filtered_data]

        if ages:
            results[condition_name] = {
                "Average Age": mean(ages),
                "Modal Age": mode(ages),
                "Median Age": median(ages)
            }

    save_to_file(results, output_file)
    return results




#v.	A function for computing the average age, modal age, median age of those who lived in urban areas and for those in rural areas that had stroke.
def stroke_residence_analysis(dataset, output_file="stroke_residence_analysis.csv"):
    results = {}

    conditions = {
        "Urban Residents with Stroke": lambda r: r["Residence Type"] == "Urban" and r["Stroke Occurrence"] == "1",
        "Rural Residents with Stroke": lambda r: r["Residence Type"] == "Rural" and r["Stroke Occurrence"] == "1"
    }

    for condition_name, condition in conditions.items():
        filtered_data = [record for record in dataset.values() if condition(record)]

        if not filtered_data:
            results[condition_name] = "No data available"
            continue

        ages = [int(record["Age"]) for record in filtered_data]

        if ages:
            results[condition_name] = {
                "Average Age": mean(ages),
                "Modal Age": mode(ages),
                "Median Age": median(ages)
            }

    save_to_file(results, output_file)
    return results


#vi.	A function to retrieves the dietary habit(s) of those who had stroke and those who did not have stroke.
def dietary_habits_stroke(dataset, output_file="dietary_habits_stroke.csv"):
   
    count_results = {"Stroke Patients": {}, "Non-Stroke Patients": {}}
    records_results = {"Stroke Patients": {}, "Non-Stroke Patients": {}}

    for patient_id, record in dataset.items():
        # Checks if required fields are in the record
        if "Dietary Habits" not in record or "Stroke Occurrence" not in record:
            continue  # Skip records missing required fields

        # Get values for dietary habits and stroke status
        dietary_habit = record["Dietary Habits"].strip() if record["Dietary Habits"] else None
        stroke_status = "Stroke Patients" if record["Stroke Occurrence"] == "1" else "Non-Stroke Patients"

        if dietary_habit:
            # Count occurrences of each dietary habit by stroke status
            count_results[stroke_status][dietary_habit] = count_results[stroke_status].get(dietary_habit, 0) + 1
            # Store the full patient record based on stroke status and dietary habit
            records_results[stroke_status].setdefault(dietary_habit, []).append(record)

    # Save the results to a csv file
    with open(output_file, "w", encoding="utf-8") as file:
        file.write("Dietary Habits Count:\n")
        for category, habits in count_results.items():
            file.write(f"{category}:\n")
            for habit, count in habits.items():
                file.write(f"  {habit}: {count}\n")
            file.write("\n")

        file.write("Detailed Patient Records:\n")
        for category, habits in records_results.items():
            file.write(f"{category}:\n")
            for habit, records in habits.items():
                file.write(f"  {habit}:\n")
                for record in records:
                    file.write(f"    {record}\n")
                file.write("\n")

    return {"Counts": count_results, "Records": records_results}




# vii.	A function that returns anyone whose hypertension resulted in stroke.

def hypertension_stroke_records(dataset, output_file="hypertension_stroke_patients.csv"):
    
    hypertension_stroke_records = []

    for record in dataset.values():
        if "Hypertension" not in record or "Stroke Occurrence" not in record:
            continue  # Skip records missing required fields

        if record["Hypertension"] == "1" and record["Stroke Occurrence"] == "1":
            hypertension_stroke_records.append(record)

    if not hypertension_stroke_records:
        print("No records found where hypertension resulted in stroke.")
        return []

    # Get the column headers from the first record
    headers = list(hypertension_stroke_records[0].keys())

    # Save the results to a CSV file
    with open(output_file, "w", encoding="utf-8") as file:
        file.write(",".join(headers) + "\n")  # Write column headers as the first row
        for record in hypertension_stroke_records:
            file.write(",".join(record.values()) + "\n")  # Write each patient's data as a row

    print(f"Hypertension-related stroke patient data saved to {output_file}")

    return [headers] + [list(record.values()) for record in hypertension_stroke_records]






#viii. A function to retrieve those who hypertension did not result in stroke and those whose hypertension resulted in stroke
def hypertension_stroke_status(dataset, stroke_file="hypertension_stroke.csv", no_stroke_file="hypertension_no_stroke.csv"):
   
    hypertension_stroke = []       # List for patients where hypertension resulted in stroke
    hypertension_no_stroke = []    # List for patients where hypertension did not result in stroke

    for record in dataset.values():
        if "Hypertension" not in record or "Stroke Occurrence" not in record:
            continue  # Skip records missing required fields

        if record["Hypertension"] == "1" and record["Stroke Occurrence"] == "1":
            hypertension_stroke.append(list(record.values()))
        elif record["Hypertension"] == "1" and record["Stroke Occurrence"] == "0":
            hypertension_no_stroke.append(list(record.values()))

    # Get column headers from the dataset
    headers = list(dataset[next(iter(dataset))].keys()) if dataset else []

    if not hypertension_stroke and not hypertension_no_stroke:
        print("No matching records found.")
        return {}

    # Write to hypertension_stroke.csv
    with open(stroke_file, "w", encoding="utf-8") as file:
        file.write(",".join(headers) + "\n")  # Column headers
        for record in hypertension_stroke:
            file.write(",".join(record) + "\n")

    # Write to hypertension_no_stroke.csv
    with open(no_stroke_file, "w", encoding="utf-8") as file:
        file.write(",".join(headers) + "\n")  # Column headers
        for record in hypertension_no_stroke:
            file.write(",".join(record) + "\n")

    print(f"Hypertension stroke data saved to {stroke_file} and {no_stroke_file}")

    return {
        "Hypertension & Stroke": [headers] + hypertension_stroke,
        "Hypertension & No Stroke": [headers] + hypertension_no_stroke
    }





#ix. A function that returns everyone with heart disease that has stroke.
def stroke_heart_disease_retrieve(dataset, output_file="stroke_heart_disease_retrieve.csv"):
    heart_disease_stroke = []  # List to store relevant records

    for record in dataset.values():
        if "Heart Disease" not in record or "Stroke Occurrence" not in record:
            continue  # Skip records missing required fields

        if record["Heart Disease"] == "1" and record["Stroke Occurrence"] == "1":
            heart_disease_stroke.append(list(record.values()))

    # Get column headers from the dataset
    headers = list(dataset[next(iter(dataset))].keys()) if dataset else []

    if not heart_disease_stroke:
        print("No matching records found.")
        return {}

    # Save results to a CSV file
    with open(output_file, "w", encoding="utf-8") as file:
        file.write(",".join(headers) + "\n")  # Column headers
        for record in heart_disease_stroke:
            file.write(",".join(record) + "\n")

    print(f"Heart disease stroke data saved to {output_file}")


    return {
        "Heart Disease & Stroke": [headers] + heart_disease_stroke
    }





#x.	A function that returns the descriptive statistics of any of the features of the dataset. This function should ask for which feature to analyse and then return the statistics. The descriptive statistics are mean, standard deviation, minimum, maximum, 25%, 50%, and 75%. 
def descriptive_feature_analysis(dataset, feature, output_file="descriptive_statistics.csv"):
    return descriptive_statistics(dataset, feature, output_file)




#xi. A function to retrieve the average sleep hours of those who had stroke and those who did not have stroke
def average_sleep_hours_by_stroke(dataset, output_file="average_sleep_hours_by_stroke.csv"):
    sleep_hours = {"stroke": [], "no_stroke": []}

    for record in dataset.values():
        if "Sleep Hours" in record and "Stroke Occurrence" in record:
            try:
                sleep = float(record["Sleep Hours"])  # Convert sleep hours to float
                if record["Stroke Occurrence"] == "1":
                    sleep_hours["stroke"].append(sleep)
                else:
                    sleep_hours["no_stroke"].append(sleep)
            except ValueError:
                continue  # Skip records with invalid sleep hours
    
    # Compute averages
    avg_stroke = sum(sleep_hours["stroke"]) / len(sleep_hours["stroke"]) if sleep_hours["stroke"] else 0
    avg_no_stroke = sum(sleep_hours["no_stroke"]) / len(sleep_hours["no_stroke"]) if sleep_hours["no_stroke"] else 0

    result = {
        "Average Sleep Hours (Stroke)": avg_stroke,
        "Average Sleep Hours (No Stroke)": avg_no_stroke
    }

    # Save results to file
    with open(output_file, "w", encoding="utf-8") as file:
        for key, value in result.items():
            file.write(f"{key}: {value:.2f}\n")

    return result
