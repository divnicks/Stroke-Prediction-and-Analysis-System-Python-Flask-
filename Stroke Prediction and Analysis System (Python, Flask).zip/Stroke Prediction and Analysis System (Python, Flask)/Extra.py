def filter_query_results(results, selected_features):
    filtered_results = []
    for row in results:
        filtered_row = {key: row[key] for key in selected_features if key in row}
        filtered_results.append(filtered_row)

    return filtered_results

def load_query_results(output_file):
    try:
        with open(output_file, "r", encoding="utf-8") as file:
            lines = file.readlines()
        if not lines:
            return [], []
        headers = lines[0].strip().split(",")
        results = [dict(zip(headers, line.strip().split(","))) for line in lines[1:]]
        return results, headers
    except FileNotFoundError:
        return [], []

def explore_results(output_file, selected_features):
    results = []
    
    try:
        with open(output_file, "r", encoding="utf-8") as file:
            headers = file.readline().strip().split(",")  # Read column names
            
            # Determine which columns to keep
            feature_indices = [headers.index(feature) for feature in selected_features if feature in headers]

            # Read and filter the rest of the file
            for line in file:
                values = line.strip().split(",")
                filtered_record = {headers[i]: values[i] for i in feature_indices}
                results.append(filtered_record)
    except Exception as e:
        print(f"Error reading file {output_file}: {str(e)}")
        return []

    return results
